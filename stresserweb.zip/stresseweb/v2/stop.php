<?php
  define('allow', true);
  define('api', true);
  
  include_once('../inc.php');

// GET Info
 $GET = filter_input_array(INPUT_GET, FILTER_SANITIZE_FULL_SPECIAL_CHARS);

// Define variables
  $userID = @$GET['user'];
  $api_key = @$GET['api_key'];
  $stopper = @$GET['stopper'];
  $error = '';

//Check user variables
  if (empty($userID)) {
    if (empty($message)) {
      $message = array(
       "status" => 'false',
       "message" => "UserID cant be empty."
      );
      $error = true;
      header("Content-Type: application/json");
      die(json_encode($message));
    }
  }
//Check api_key variables
  if (empty($api_key)) {
    if (empty($message)) {
      $message = array(
       "status" => 'false',
       "message" => "API Key cant be empty."
      );
      $error = true;
      header("Content-Type: application/json");
      die(json_encode($message));
    }
  }

//Check user variables
  if (empty($stopper)) {
    if (empty($message)) {
      $message = array(
       "status" => 'false',
       "message" => "Stopper cant be empty."
      );
      $error = true;
      header("Content-Type: application/json");
      die(json_encode($message));
    }
  }

// Check if user has valid api_key
  if ($Api->UsersApiDataID2(@$api_key, 1)['userID'] != @$userID) {
    if (empty($message)) {
      // Message
      $message = array(
       "status" => 'false',
       "message" => "Indicated user ID not have same API keys."
      );
      $error = true;
      header("Content-Type: application/json");
      die(json_encode($message));
    }
  }

// Check if user has api access
  if ($Api->UsersApiDataID2($api_key, 1)['api_key'] == $api_key) {
    if ($Plan->PlanDataID($User->UserDataID(@$userID, 1)['plan'])['api'] != 1) {
      if (empty($message)) {
        // Message
        $message = array(
         "status" => 'false',
         "message" => "Your plan doesnt support API Access."
        );
        $error = true;
        header("Content-Type: application/json");
        die(json_encode($message));
      }
    }
  }

//Check expiration time of the plan
  if ($User->UserDataID(@$userID, 1)['expire'] < time()) {
    if (empty($message)) {
      // Message
      $message = array(
       "status" => 'false',
       "message" => "Your Plan is expired."
      );
      $error = true;
      header("Content-Type: application/json");
      die(json_encode($message));
    }
  }

// Check is IP Whitelisted
  $WL = $Api->UsersApiDataID2($api_key, 1)['WhiteList'];
  $IpExplode = explode('|', $Secure->ApiIps($WL));
  
  if (filter_var($IpExplode[0], FILTER_VALIDATE_IP)) {
    if ($IpExplode[0] != $User->UserIP()) {
      if ($IpExplode[1] != $User->UserIP()) {
        if ($IpExplode[2] != $User->UserIP()) {
          if (empty($message)) {
            // Message
            $message = array(
             "status" => 'false',
             "message" => "This ip is not White Listed"
            );
            $error = true;
            header("Content-Type: application/json");
            die(json_encode($message));
          }
        }
      }
    }
  }
  
  if ($ALogs->LogsDataStopper($stopper, 1)['userID'] != @$userID) {
    if (empty($message)) {
      
      $test = $ALogs->LogsDataStopper($stopper, 1)['userID'];
      // Message
      $message = array(
       "status" => 'false',
       "message" => "This is not your attack. $test"
      );
      $error = true;
      header("Content-Type: application/json");
      die(json_encode($message));
    }
  }
  
  if ($ALogs->LogsDataStopper($stopper, 1)['stopped'] != 0) {
    if (empty($message)) {
      // Message
      $message = array(
       "status" => 'false',
       "message" => "This attack is stopped."
      );
      $error = true;
      header("Content-Type: application/json");
      die(json_encode($message));
    }
  }
  
  if ($ALogs->LogsDataStopper($stopper, 1)['date'] + $ALogs->LogsDataStopper($stopper, 1)['time'] < time()) {
    if (empty($message)) {
      // Message
      $message = array(
       "status" => 'false',
       "message" => "This attack is expired."
      );
      $error = true;
      header("Content-Type: application/json");
      die(json_encode($message));
    }
  }
  
  if($error == false) {
    $Data = $ALogs->LogsDataStopper($stopper, 1);
    
    //Define variables
    $serverID = $Data['handler'];
    
    // Set the API link
    $api_link = $Api->ApiDataID($Data['handler'], 1)['link'];
    
    // Set the default values for the action and mode parameters
    $default_action = "stop";
    
    // Use a regular expression to find all of the parameter placeholders in the API link
    $pattern = "/\[([^\]]+)\]/";
    
    // Use preg_replace_callback to replace the placeholders with their corresponding values
    $api_link = preg_replace_callback($pattern, function ($matches) use ($default_action, $stopper) {
      // Get the parameter name from the matches
      $param_name = $matches[1];
      
      // Check the parameter name and return the corresponding value
      switch ($param_name) {
        case "action":
          return $default_action;
        case "stopper":
          return $stopper;
        default:
          return "";
      }
    }, $api_link);
    
    // Set the URL, HTTP headers, and timeout options for the request
    $options = [
     'url' => $api_link,
     'headers' => [
      'cache-control' => 'no-cache',
      'content-type' => 'application/x-www-form-urlencoded',
     ],
     'timeout' => 5,
    ];
    
    try {
      // Send the HTTP request and get the response
      $response = $Client->request('GET', $options['url'], [
       'headers' => $options['headers'],
       'timeout' => $options['timeout'],
      ]);
      
      $data = [
       'response' => json_decode($response->getBody()->getContents(), true)
      ];

//      file_put_contents("stop.json", json_encode($data));
//      file_put_contents("link.json", json_encode($api_link));
      
      // Return a success message
      $message = array(
       "status" => 'true',
       "message" => "Attack stopped"
      );
      
      $DataBase->Query("UPDATE `attack_logs` SET `stopped`='1' WHERE `stopper`=:stopper");
      $DataBase->Bind(':stopper', $stopper);
      $DataBase->Execute();
      
    } catch (\Exception $e) {
      // Return an error message
      $message = array(
       "status" => 'false',
       "message" => "Attack stopped"
      );
    }
  }

// Json App Header
  header("Content-Type: application/json");
// Encode
  $print = json_encode($message ?? []);
// Print
  print_r($print);
  die();

?>