<?php
// Define Includes
define('allow', true);
define('api', true);
//Path includes
include_once('../inc.php');

//Define variables
$userID = (int)@$_GET['user'];
$api_key = @$_GET['api_key'];

error_reporting(E_ALL);
error_reporting(1);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

//Check user variables
if (empty($userID)) {
    if (empty($message)) {
        header('Content-Type: application/json');
        die(json_encode(['status' => false, 'message' => "UserID is empty"]));
    }
}
//Check api_key variables
if (empty($api_key)) {
    if (empty($message)) {
        header('Content-Type: application/json');
        die(json_encode(['status' => false, 'message' => "API key is empty"]));
    }
}

// Check if user has valid api_key
if ($Api->UsersApiDataID2(@$api_key, 1)['userID'] != $userID) {
    if (empty($message)) {
        header('Content-Type: application/json');
        die(json_encode(['status' => false, 'message' => "API key does not belong to user"]));
    }
}

//Get account information
$userData = $User->UserDataID($userID, 0)['Response'];
$plan_data = $Plan->PlanDataID($userData[0]['plan']);

$addons = explode('|', $User->UserDataID($userID, 1)['addons']);


$userslots = $plan_data['concurrents'] + $addons['0'];
$userRunningAttack = $ALogs->LogsDataRunningUserID($userID, 0)['Count'];


// Get attacks data and filter based on the condition
$attacksDataAll = $ALogs->LogsDataUserID($userID, 0)['Response'];
$filteredAttacks = array_filter($attacksDataAll, fn($Sv) => $Sv['time'] + $Sv['date'] > time() && $Sv['stopped'] == 0);

$extractedAttacks = array_values(array_map(function ($Ai) use ($Methods) {
    $Time = $Ai['time'] + $Ai['date'] - time();
    return [
        'attack_id' => $Ai['stopper'],
        'target' => $Ai['target'],
        'host' => $Ai['host'],
        'port' => $Ai['port'],
        'method' => $Methods->MethodsDataID($Ai['method'])['apiname'],
        'stopped' => boolval($Ai['stopped']),
        'expire' => $Time,
        'type' => $Ai['type'],
    ];
}, $filteredAttacks));

//Get network information
$networkrunning = $ALogs->LogsDataRunning()['Count'];
$networkslots = $Api->ApiSlots();

// Create an associative array for the JSON output
$output = [
    "status" => 200,
    "message" => "attacks information",
    "account" => [
        "running" => (int)$userRunningAttack,
        "slots" => (int)$userslots
    ],
    "network" => [
        "networkRunning" => (int)$networkrunning,
        "networkSlots" => (int)$networkslots
    ],
    "attacks" => [
        $extractedAttacks,
    ]
];

// Convert the array to JSON and echo it
header('Content-Type: application/json');
echo json_encode($output);


?>